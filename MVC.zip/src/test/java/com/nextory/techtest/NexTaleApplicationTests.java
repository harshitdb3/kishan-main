package com.nextory.techtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NexTaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
